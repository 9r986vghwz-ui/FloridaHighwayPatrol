
ALTER TABLE supervisor_keys ADD COLUMN expires_at DATETIME;
