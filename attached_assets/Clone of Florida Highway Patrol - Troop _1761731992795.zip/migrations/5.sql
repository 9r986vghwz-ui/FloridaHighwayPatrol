
ALTER TABLE troopers ADD COLUMN phone TEXT;
ALTER TABLE troopers ADD COLUMN email TEXT;
ALTER TABLE troopers ADD COLUMN badge_number TEXT;
