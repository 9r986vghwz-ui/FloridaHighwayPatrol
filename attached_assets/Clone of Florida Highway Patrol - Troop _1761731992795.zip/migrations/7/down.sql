
ALTER TABLE troopers DROP COLUMN denied_by_user_id;
ALTER TABLE troopers DROP COLUMN denied_at;
ALTER TABLE troopers DROP COLUMN denial_reason;
ALTER TABLE troopers DROP COLUMN profile_status;
