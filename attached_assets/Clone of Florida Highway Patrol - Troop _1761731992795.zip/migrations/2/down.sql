
ALTER TABLE supervisor_keys DROP COLUMN expires_at;
