
DROP INDEX idx_strikes_trooper_id;
DROP INDEX idx_reports_needs_revision;
DROP INDEX idx_reports_status;
DROP TABLE strikes;
ALTER TABLE reports DROP COLUMN revised_at;
ALTER TABLE reports DROP COLUMN needs_revision;
ALTER TABLE reports DROP COLUMN denied_by_user_id;
ALTER TABLE reports DROP COLUMN denied_at;
ALTER TABLE reports DROP COLUMN denial_notes;
ALTER TABLE reports DROP COLUMN report_status;
