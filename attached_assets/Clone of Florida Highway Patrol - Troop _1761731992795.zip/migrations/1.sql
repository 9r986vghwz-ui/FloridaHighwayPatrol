
CREATE TABLE troopers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE,
  serial_number TEXT NOT NULL UNIQUE,
  callsign TEXT NOT NULL,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  rank TEXT NOT NULL,
  is_approved BOOLEAN DEFAULT FALSE,
  approved_by_user_id TEXT,
  approved_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trooper_id INTEGER NOT NULL,
  report_type TEXT NOT NULL, -- 'citation', 'arrest', 'bolo', 'collision'
  report_data TEXT NOT NULL, -- JSON data for the report
  report_number TEXT,
  location TEXT,
  incident_date DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE supervisor_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key_code TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT TRUE,
  created_by_user_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_troopers_user_id ON troopers(user_id);
CREATE INDEX idx_troopers_serial ON troopers(serial_number);
CREATE INDEX idx_reports_trooper_id ON reports(trooper_id);
CREATE INDEX idx_reports_type ON reports(report_type);
CREATE INDEX idx_supervisor_keys_code ON supervisor_keys(key_code);
