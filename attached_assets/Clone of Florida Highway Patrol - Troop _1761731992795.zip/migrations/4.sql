
ALTER TABLE reports ADD COLUMN report_status TEXT DEFAULT 'pending';
ALTER TABLE reports ADD COLUMN denial_notes TEXT;
ALTER TABLE reports ADD COLUMN denied_at DATETIME;
ALTER TABLE reports ADD COLUMN denied_by_user_id TEXT;
ALTER TABLE reports ADD COLUMN needs_revision BOOLEAN DEFAULT FALSE;
ALTER TABLE reports ADD COLUMN revised_at DATETIME;

CREATE TABLE strikes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trooper_id INTEGER NOT NULL,
  report_id INTEGER,
  reason TEXT NOT NULL,
  issued_by_user_id TEXT NOT NULL,
  issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reports_status ON reports(report_status);
CREATE INDEX idx_reports_needs_revision ON reports(needs_revision);
CREATE INDEX idx_strikes_trooper_id ON strikes(trooper_id);
