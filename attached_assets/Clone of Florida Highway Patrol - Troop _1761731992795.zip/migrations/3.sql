
INSERT INTO supervisor_keys (key_code, is_active, created_by_user_id) 
VALUES ('FHP2025-9445', 1, 'system');
