
ALTER TABLE troopers DROP COLUMN badge_number;
ALTER TABLE troopers DROP COLUMN email;
ALTER TABLE troopers DROP COLUMN phone;
