
DELETE FROM supervisor_keys WHERE key_code = 'FHP2025-9445';
