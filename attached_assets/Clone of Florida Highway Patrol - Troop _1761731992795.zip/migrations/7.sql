
ALTER TABLE troopers ADD COLUMN profile_status TEXT DEFAULT 'pending';
ALTER TABLE troopers ADD COLUMN denial_reason TEXT;
ALTER TABLE troopers ADD COLUMN denied_at DATETIME;
ALTER TABLE troopers ADD COLUMN denied_by_user_id TEXT;
