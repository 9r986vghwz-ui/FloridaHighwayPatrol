
DROP INDEX idx_supervisor_keys_code;
DROP INDEX idx_reports_type;
DROP INDEX idx_reports_trooper_id;
DROP INDEX idx_troopers_serial;
DROP INDEX idx_troopers_user_id;
DROP TABLE supervisor_keys;
DROP TABLE reports;
DROP TABLE troopers;
