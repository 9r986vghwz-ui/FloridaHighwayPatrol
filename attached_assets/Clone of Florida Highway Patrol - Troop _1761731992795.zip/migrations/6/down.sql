
DROP TABLE user_roles;
ALTER TABLE supervisor_keys DROP COLUMN created_by_serial_number;
