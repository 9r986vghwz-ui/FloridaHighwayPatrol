import { useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { Shield, Users, FileText, Lock } from 'lucide-react';
import LoginButton from '@/react-app/components/LoginButton';

export default function Home() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !isPending) {
      navigate('/dashboard');
    }
  }, [user, isPending, navigate]);

  if (isPending) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          {/* Header */}
          <div className="mb-16">
            <div className="flex items-center justify-center mb-6">
              <Shield className="w-16 h-16 text-blue-400 mr-4" />
              <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                Florida Highway Patrol
              </h1>
            </div>
            <p className="text-2xl font-semibold text-blue-300 mb-4">Troop E</p>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Professional law enforcement dashboard for Troop E operations, report management, and supervisor oversight
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
              <FileText className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Report Management</h3>
              <p className="text-gray-400">Create and manage citations, arrests, BOLOs, and collision reports</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
              <Users className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Trooper Profiles</h3>
              <p className="text-gray-400">Secure registration with supervisor approval system</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
              <Lock className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Supervisor Panel</h3>
              <p className="text-gray-400">Administrative controls and approval management</p>
            </div>
          </div>

          {/* Login Section */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-8 border border-gray-700 max-w-md mx-auto">
            <h2 className="text-2xl font-semibold mb-4">Get Started</h2>
            <p className="text-gray-300 mb-6">
              Sign up with your Google account to create your trooper profile
            </p>
            <LoginButton />
            <p className="text-sm text-gray-400 mt-4">
              New registrations require supervisor approval
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
