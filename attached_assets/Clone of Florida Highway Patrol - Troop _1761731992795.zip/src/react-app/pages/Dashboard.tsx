import { useEffect, useState } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { TrooperType, ReportType } from '@/shared/types';
import { Shield, FileText, Plus, Settings, LogOut, Edit2 } from 'lucide-react';
import TrooperRegistration from '@/react-app/components/TrooperRegistration';
import ReportForm from '@/react-app/components/ReportForm';
import ReportStats from '@/react-app/components/ReportStats';
import SupervisorKeyEntry from '@/react-app/components/SupervisorKeyEntry';
import PendingApprovalModal from '@/react-app/components/PendingApprovalModal';
import ProfileEditor from '@/react-app/components/ProfileEditor';
import KeyCreator from '@/react-app/components/KeyCreator';
import ProfileDenialModal from '@/react-app/components/ProfileDenialModal';

export default function Dashboard() {
  const { user, logout, isPending } = useAuth();
  const navigate = useNavigate();
  const [trooper, setTrooper] = useState<TrooperType | null>(null);
  const [reports, setReports] = useState<ReportType[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'create-report' | 'edit-profile'>('overview');
  const [loading, setLoading] = useState(true);
  const [showKeyEntry, setShowKeyEntry] = useState(false);
  const [showKeyCreator, setShowKeyCreator] = useState(false);
  const [showProfileEditor, setShowProfileEditor] = useState(false);
  const [editingReport, setEditingReport] = useState<ReportType | null>(null);

  useEffect(() => {
    if (!user && !isPending) {
      navigate('/');
      return;
    }
    
    if (user) {
      console.log('User authenticated, fetching profile...');
      fetchTrooperProfile();
    }
  }, [user, isPending, navigate]);

  // Automatically fetch profile if registration succeeds
  useEffect(() => {
    if (trooper) {
      setLoading(false);
    }
  }, [trooper]);

  const fetchTrooperProfile = async () => {
    console.log('Fetching trooper profile...');
    setLoading(true);
    try {
      const response = await fetch('/api/troopers/me', {
        credentials: 'include'
      });
      if (response.ok) {
        const trooperData = await response.json();
        console.log('Trooper data received:', trooperData);
        setTrooper(trooperData);
        if (trooperData.is_approved) {
          fetchReports();
        }
      } else if (response.status === 404) {
        console.log('No trooper profile found');
        // Profile doesn't exist, keep showing registration form
        setTrooper(null);
      } else {
        console.error('Failed to fetch trooper profile, status:', response.status);
        const errorText = await response.text().catch(() => 'Unknown error');
        console.error('Error response:', errorText);
        setTrooper(null);
      }
    } catch (error) {
      console.error('Failed to fetch trooper profile:', error);
      setTrooper(null);
    } finally {
      setLoading(false);
    }
  };

  const fetchReports = async () => {
    try {
      const response = await fetch('/api/reports', {
        credentials: 'include'
      });
      if (response.ok) {
        const reportsData = await response.json();
        setReports(reportsData);
      }
    } catch (error) {
      console.error('Failed to fetch reports:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const handleSupervisorAccess = () => {
    navigate('/supervisor');
  };

  if (isPending || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!trooper) {
    return (
      <div className="min-h-screen bg-gray-900 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-blue-400" />
              <h1 className="text-2xl font-bold">Florida Highway Patrol - Troop E</h1>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
          <TrooperRegistration onSuccess={fetchTrooperProfile} />
        </div>
      </div>
    );
  }

  if (!trooper.is_approved) {
    const handleResubmitProfile = async () => {
      try {
        await fetch('/api/troopers/me', {
          method: 'DELETE',
          credentials: 'include'
        });
        setTrooper(null);
      } catch (error) {
        console.error('Failed to delete profile for resubmission:', error);
      }
    };

    return (
      <div className="min-h-screen bg-gray-900 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-blue-400" />
              <h1 className="text-2xl font-bold">Florida Highway Patrol - Troop E</h1>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
        {(trooper as any).profile_status === 'denied' ? (
          <ProfileDenialModal
            trooper={trooper}
            denialReason={(trooper as any).denial_reason || 'No reason provided'}
            onResubmit={handleResubmitProfile}
          />
        ) : (
          <PendingApprovalModal 
            trooper={trooper} 
            onAdminApproval={fetchTrooperProfile}
          />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Navigation */}
      <nav className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-blue-400" />
              <h1 className="text-xl font-bold">Florida Highway Patrol - Troop E</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-gray-300">
                Welcome back, {trooper.rank} {trooper.last_name}
              </span>
              <button
                onClick={() => setShowKeyCreator(true)}
                className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors mr-2"
              >
                <Settings className="w-4 h-4" />
                Create Key
              </button>
              <button
                onClick={() => setShowKeyEntry(true)}
                className="flex items-center gap-2 px-3 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors"
              >
                <Settings className="w-4 h-4" />
                Supervisor
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Tab Navigation */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-6">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'overview'
                  ? 'border-blue-400 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'reports'
                  ? 'border-blue-400 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              Reports
            </button>
            <button
              onClick={() => {
                setEditingReport(null);
                setActiveTab('create-report');
              }}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'create-report'
                  ? 'border-blue-400 text-blue-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Plus className="w-4 h-4 inline mr-1" />
              Create Report
            </button>
            
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'overview' && (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Profile Card */}
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Trooper Profile</h3>
                <button
                  onClick={() => setShowProfileEditor(true)}
                  className="flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
              </div>
              {!showProfileEditor ? (
                <div className="space-y-2">
                  <p><span className="text-gray-400">Serial #:</span> {trooper.serial_number.length > 8 ? `...${trooper.serial_number.slice(-5)}` : trooper.serial_number}</p>
                  <p><span className="text-gray-400">Callsign:</span> {trooper.callsign}</p>
                  <p><span className="text-gray-400">Name:</span> {trooper.first_name} {trooper.last_name}</p>
                  <p><span className="text-gray-400">Rank:</span> {trooper.rank}</p>
                  {trooper.badge_number && (
                    <p><span className="text-gray-400">Badge #:</span> {(() => {
                      const badgeNum = trooper.badge_number;
                      // If it's a long string of numbers, show only last 5
                      if (badgeNum && /^\d{6,}$/.test(badgeNum)) {
                        return `...${badgeNum.slice(-5)}`;
                      }
                      return badgeNum;
                    })()}</p>
                  )}
                  {trooper.phone && (
                    <p><span className="text-gray-400">Phone:</span> {(() => {
                      const phone = trooper.phone;
                      // If it's a long string of numbers, show only last 5
                      if (phone && /^\d{6,}$/.test(phone.replace(/\D/g, ''))) {
                        const digits = phone.replace(/\D/g, '');
                        return `...${digits.slice(-5)}`;
                      }
                      return phone;
                    })()}</p>
                  )}
                  {trooper.email && (
                    <p><span className="text-gray-400">Email:</span> {trooper.email}</p>
                  )}
                  <p><span className="text-gray-400">Status:</span> 
                    <span className="text-green-400 ml-1">Approved</span>
                  </p>
                </div>
              ) : (
                <ProfileEditor
                  trooper={trooper}
                  onSuccess={() => {
                    fetchTrooperProfile();
                    setShowProfileEditor(false);
                  }}
                  onCancel={() => setShowProfileEditor(false)}
                />
              )}
            </div>

            {/* Stats */}
            <div className="lg:col-span-2">
              <ReportStats />
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Your Reports</h2>
            {reports.length === 0 ? (
              <div className="bg-gray-800 rounded-xl p-8 text-center border border-gray-700">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No reports created yet</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {reports.map((report) => {
                  const getStatusBadge = (status: string | null) => {
                    switch (status) {
                      case 'pending':
                        return <span className="px-2 py-1 bg-yellow-900/20 text-yellow-400 rounded text-xs font-medium">Pending Review</span>;
                      case 'approved':
                        return <span className="px-2 py-1 bg-green-900/20 text-green-400 rounded text-xs font-medium">Approved</span>;
                      case 'denied':
                        return <span className="px-2 py-1 bg-red-900/20 text-red-400 rounded text-xs font-medium">Denied - Needs Revision</span>;
                      default:
                        return null;
                    }
                  };

                  return (
                    <div key={report.id} className={`bg-gray-800 rounded-lg p-4 border ${report.needs_revision ? 'border-red-500' : 'border-gray-700'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <h3 className="font-semibold capitalize">{report.report_type}</h3>
                          {getStatusBadge(report.report_status)}
                        </div>
                        <span className="text-sm text-gray-400">
                          {new Date(report.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      {report.report_number && (
                        <p className="text-sm text-gray-300 mb-1">
                          Report #: {report.report_number}
                        </p>
                      )}
                      {report.location && (
                        <p className="text-sm text-gray-400 mb-2">Location: {report.location}</p>
                      )}
                      {report.denial_notes && (
                        <div className="mt-3 p-3 bg-red-900/20 border border-red-700 rounded">
                          <p className="text-sm font-semibold text-red-400 mb-1">Supervisor Feedback:</p>
                          <p className="text-sm text-red-300">{report.denial_notes}</p>
                          <button
                            onClick={() => {
                              setEditingReport(report);
                              setActiveTab('create-report');
                            }}
                            className="mt-2 text-sm text-red-400 hover:text-red-300 underline"
                          >
                            Click here to revise this report
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'create-report' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">{editingReport ? 'Revise Report' : 'Create New Report'}</h2>
            {editingReport && (
              <div className="bg-orange-900/20 border border-orange-700 rounded-lg p-4 mb-6">
                <p className="text-orange-400 font-semibold mb-2">This report was denied by a supervisor</p>
                <p className="text-sm text-orange-300">Please review the feedback and make the necessary changes before resubmitting.</p>
              </div>
            )}
            <ReportForm 
              reportId={editingReport?.id}
              initialData={editingReport}
              onSuccess={() => {
                fetchReports();
                setEditingReport(null);
                setActiveTab('reports');
              }} 
            />
          </div>
        )}

        
      </div>

      {/* Supervisor Key Entry Modal */}
      {showKeyEntry && (
        <SupervisorKeyEntry
          onSuccess={handleSupervisorAccess}
          onClose={() => setShowKeyEntry(false)}
        />
      )}

      {/* Key Creator Modal */}
      {showKeyCreator && trooper && (
        <KeyCreator
          trooperSerialNumber={trooper.serial_number}
          onClose={() => setShowKeyCreator(false)}
        />
      )}
    </div>
  );
}
