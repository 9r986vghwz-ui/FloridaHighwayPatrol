import { useEffect, useState } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { Shield, Users, Key, ArrowLeft, FileText } from 'lucide-react';
import SupervisorReportReview from '@/react-app/components/SupervisorReportReview';
import SupervisorPendingProfiles from '@/react-app/components/SupervisorPendingProfiles';

export default function Supervisor() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'pending-profiles' | 'reports' | 'keys'>('pending-profiles');
  const [keyHistory, setKeyHistory] = useState<any[]>([]);
  const [loadingKeys, setLoadingKeys] = useState(false);

  useEffect(() => {
    if (!user && !isPending) {
      navigate('/');
      return;
    }
    
    if (user) {
      setLoading(false);
      if (activeTab === 'keys') {
        fetchKeyHistory();
      }
    }
  }, [user, isPending, navigate]);

  const fetchKeyHistory = async () => {
    setLoadingKeys(true);
    try {
      const response = await fetch('/api/supervisor/key-history', {
        credentials: 'include'
      });
      if (response.ok) {
        const keys = await response.json();
        setKeyHistory(keys);
      }
    } catch (error) {
      console.error('Failed to fetch key history:', error);
    } finally {
      setLoadingKeys(false);
    }
  };

  

  

  if (isPending || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Navigation */}
      <nav className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </button>
              <div className="flex items-center gap-3">
                <Shield className="w-8 h-8 text-purple-400" />
                <h1 className="text-xl font-bold">Supervisor Panel</h1>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Tab Navigation */}
      <div className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-6">
            <button
              onClick={() => setActiveTab('pending-profiles')}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'pending-profiles'
                  ? 'border-purple-400 text-purple-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 inline mr-1" />
              Pending Profiles
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'reports'
                  ? 'border-purple-400 text-purple-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <FileText className="w-4 h-4 inline mr-1" />
              Review Reports
            </button>
            <button
              onClick={() => {
                setActiveTab('keys');
                fetchKeyHistory();
              }}
              className={`py-3 px-1 border-b-2 transition-colors ${
                activeTab === 'keys'
                  ? 'border-purple-400 text-purple-400'
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
            >
              <Key className="w-4 h-4 inline mr-1" />
              Key History
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'pending-profiles' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Pending Profile Approvals</h2>
            <SupervisorPendingProfiles />
          </div>
        )}

        {activeTab === 'reports' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Review Reports</h2>
            <SupervisorReportReview />
          </div>
        )}

        {activeTab === 'keys' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Supervisor Key History</h2>
            
            {loadingKeys ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
              </div>
            ) : keyHistory.length === 0 ? (
              <div className="bg-gray-800 rounded-xl p-8 text-center border border-gray-700">
                <Key className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No supervisor keys have been created yet</p>
                <p className="text-sm text-gray-500 mt-2">
                  Troopers can create temporary access keys from their dashboard
                </p>
              </div>
            ) : (
              <div className="grid gap-4">
                {keyHistory.map((key) => {
                  const isExpired = new Date(key.expires_at) < new Date();
                  const isActive = key.is_active && !isExpired;
                  
                  return (
                    <div key={key.id} className={`bg-gray-800 rounded-lg p-4 border ${
                      isActive ? 'border-green-500' : 'border-gray-700'
                    }`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <code className="text-lg font-mono text-purple-400">{key.key_code}</code>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            isActive 
                              ? 'bg-green-900/20 text-green-400' 
                              : 'bg-red-900/20 text-red-400'
                          }`}>
                            {isActive ? 'Active' : 'Expired'}
                          </span>
                        </div>
                        <span className="text-sm text-gray-400">
                          {new Date(key.created_at).toLocaleDateString()} at{' '}
                          {new Date(key.created_at).toLocaleTimeString()}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Created by:</span>{' '}
                          <span className="font-mono text-blue-400">
                            {key.created_by_serial_number || 'Unknown'}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-400">Expires:</span>{' '}
                          <span className={isExpired ? 'text-red-400' : 'text-yellow-400'}>
                            {new Date(key.expires_at).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-6 p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
              <h4 className="font-semibold text-blue-400 mb-2">Admin Information</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Supervisors can only view key history, not create new keys</li>
                <li>• Troopers create their own temporary access keys (15 minutes)</li>
                <li>• All key creation activity is tracked by serial number</li>
                <li>• Only active, unexpired keys can be used for access</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
