import { useState, useEffect } from 'react';
import { Check, X, AlertTriangle, Zap, Eye } from 'lucide-react';
import StrikeManager from './StrikeManager';

interface Report {
  id: number;
  trooper_id: number;
  report_number: string;
  report_type: string;
  report_status: string;
  location: string;
  incident_date: string;
  created_at: string;
  first_name: string;
  last_name: string;
  callsign: string;
  serial_number: string;
  rank: string;
  denial_notes: string | null;
  needs_revision: boolean;
  report_data: string;
}

export default function SupervisorReportReview() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [denialNotes, setDenialNotes] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState('');
  const [strikeReport, setStrikeReport] = useState<Report | null>(null);
  const [viewingReport, setViewingReport] = useState<Report | null>(null);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const response = await fetch('/api/supervisor/reports', {
        credentials: 'include'
      });
      if (response.ok) {
        const reportsData = await response.json();
        setReports(reportsData);
      }
    } catch (error) {
      console.error('Failed to fetch reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const approveReport = async (reportId: number) => {
    setActionLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/supervisor/reports/${reportId}/approve`, {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        fetchReports();
      } else {
        setError('Failed to approve report');
      }
    } catch (error) {
      setError('Failed to approve report');
    } finally {
      setActionLoading(false);
    }
  };

  const denyReport = async (reportId: number) => {
    if (!denialNotes.trim()) {
      setError('Denial notes are required');
      return;
    }

    setActionLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/supervisor/reports/${reportId}/deny`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ denial_notes: denialNotes }),
      });

      if (response.ok) {
        setSelectedReport(null);
        setDenialNotes('');
        fetchReports();
      } else {
        setError('Failed to deny report');
      }
    } catch (error) {
      setError('Failed to deny report');
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-900/20 text-yellow-400 rounded text-xs font-medium">Pending</span>;
      case 'approved':
        return <span className="px-2 py-1 bg-green-900/20 text-green-400 rounded text-xs font-medium">Approved</span>;
      case 'denied':
        return <span className="px-2 py-1 bg-red-900/20 text-red-400 rounded text-xs font-medium">Denied</span>;
      default:
        return <span className="px-2 py-1 bg-gray-700 text-gray-400 rounded text-xs font-medium">Unknown</span>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div>
      {error && (
        <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm mb-4">
          {error}
        </div>
      )}

      <div className="grid gap-4">
        {reports.map((report) => (
          <div key={report.id} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-semibold">{report.report_number}</h3>
                  {getStatusBadge(report.report_status)}
                  {report.needs_revision && (
                    <span className="flex items-center gap-1 px-2 py-1 bg-orange-900/20 text-orange-400 rounded text-xs font-medium">
                      <AlertTriangle className="w-3 h-3" />
                      Needs Revision
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                  <div>
                    <label className="text-gray-400">Type</label>
                    <p className="font-semibold capitalize">{report.report_type}</p>
                  </div>
                  <div>
                    <label className="text-gray-400">Trooper</label>
                    <p className="font-semibold">{report.rank} {report.last_name} ({report.callsign})</p>
                  </div>
                  <div>
                    <label className="text-gray-400">Location</label>
                    <p className="font-semibold">{report.location || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-gray-400">Submitted</label>
                    <p className="font-semibold">{new Date(report.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
                {report.denial_notes && (
                  <div className="mt-3 p-3 bg-red-900/10 border border-red-700 rounded">
                    <p className="text-sm text-gray-400 mb-1">Denial Reason:</p>
                    <p className="text-sm text-red-400">{report.denial_notes}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-3 mt-4">
              <button
                onClick={() => setViewingReport(report)}
                disabled={actionLoading}
                className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
              >
                <Eye className="w-4 h-4" />
                View Details
              </button>
              {report.report_status === 'pending' && (
                <>
                  <button
                    onClick={() => approveReport(report.id)}
                    disabled={actionLoading}
                    className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                  >
                    <Check className="w-4 h-4" />
                    Approve
                  </button>
                  <button
                    onClick={() => setSelectedReport(report)}
                    disabled={actionLoading}
                    className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                  >
                    <X className="w-4 h-4" />
                    Deny
                  </button>
                </>
              )}
            </div>

            {report.report_status === 'denied' && report.needs_revision && (
              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => setStrikeReport(report)}
                  disabled={actionLoading}
                  className="flex items-center gap-2 bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                >
                  <Zap className="w-4 h-4" />
                  Issue Strike for Non-Compliance
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {reports.length === 0 && (
        <div className="bg-gray-800 rounded-xl p-8 text-center border border-gray-700">
          <p className="text-gray-400">No reports to review</p>
        </div>
      )}

      {/* Denial Modal */}
      {selectedReport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 max-w-lg w-full border border-gray-700">
            <h3 className="text-xl font-semibold mb-4">Deny Report {selectedReport.report_number}</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Denial Notes (Required)
              </label>
              <textarea
                value={denialNotes}
                onChange={(e) => setDenialNotes(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
                rows={4}
                placeholder="Explain why this report is being denied and what needs to be corrected..."
                required
              />
            </div>

            <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-3 mb-4">
              <p className="text-sm text-yellow-400">
                The trooper will be notified to revise this report. If they fail to revise it within a reasonable time, you may issue a strike.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => denyReport(selectedReport.id)}
                disabled={actionLoading || !denialNotes.trim()}
                className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
              >
                {actionLoading ? 'Denying...' : 'Confirm Denial'}
              </button>
              <button
                onClick={() => {
                  setSelectedReport(null);
                  setDenialNotes('');
                  setError('');
                }}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Report Modal */}
      {viewingReport && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">Report Details - {viewingReport.report_number}</h3>
              <button
                onClick={() => setViewingReport(null)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm">Trooper</label>
                  <p className="font-semibold">{viewingReport.rank} {viewingReport.last_name} ({viewingReport.callsign})</p>
                  <p className="text-sm text-gray-400">Serial: {viewingReport.serial_number.length > 8 ? `...${viewingReport.serial_number.slice(-5)}` : viewingReport.serial_number}</p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Report Type</label>
                  <p className="font-semibold capitalize">{viewingReport.report_type}</p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Status</label>
                  <p className="font-semibold">{viewingReport.report_status}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm">Location</label>
                  <p className="font-semibold">{viewingReport.location || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Incident Date</label>
                  <p className="font-semibold">
                    {viewingReport.incident_date 
                      ? new Date(viewingReport.incident_date).toLocaleString()
                      : 'N/A'
                    }
                  </p>
                </div>
                <div>
                  <label className="text-gray-400 text-sm">Submitted</label>
                  <p className="font-semibold">{new Date(viewingReport.created_at).toLocaleString()}</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900/50 rounded-lg p-4">
              <h4 className="font-semibold mb-3">Report Data</h4>
              <pre className="text-sm text-gray-300 whitespace-pre-wrap overflow-auto">
                {JSON.stringify(JSON.parse((viewingReport as any).report_data || '{}'), null, 2)}
              </pre>
            </div>

            {viewingReport.denial_notes && (
              <div className="mt-4 p-4 bg-red-900/20 border border-red-700 rounded">
                <h4 className="font-semibold text-red-400 mb-2">Denial Notes</h4>
                <p className="text-red-300">{viewingReport.denial_notes}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Strike Modal */}
      {strikeReport && (
        <StrikeManager
          trooperId={strikeReport.trooper_id}
          trooperName={`${strikeReport.rank} ${strikeReport.last_name}`}
          reportId={strikeReport.id}
          onSuccess={() => {
            setStrikeReport(null);
            fetchReports();
          }}
          onCancel={() => setStrikeReport(null)}
        />
      )}
    </div>
  );
}
