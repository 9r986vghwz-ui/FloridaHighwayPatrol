import { useState, useEffect } from 'react';
import { Check, X, User } from 'lucide-react';

interface PendingTrooper {
  id: number;
  serial_number: string;
  callsign: string;
  first_name: string;
  last_name: string;
  rank: string;
  created_at: string;
}

export default function SupervisorPendingProfiles() {
  const [troopers, setTroopers] = useState<PendingTrooper[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTrooper, setSelectedTrooper] = useState<PendingTrooper | null>(null);
  const [denialReason, setDenialReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState('');
  const [actionType, setActionType] = useState<'approve' | 'deny' | null>(null);

  useEffect(() => {
    fetchPendingTroopers();
  }, []);

  const fetchPendingTroopers = async () => {
    try {
      const response = await fetch('/api/supervisor/pending-troopers', {
        credentials: 'include'
      });
      if (response.ok) {
        const troopersData = await response.json();
        setTroopers(troopersData);
      }
    } catch (error) {
      console.error('Failed to fetch pending troopers:', error);
    } finally {
      setLoading(false);
    }
  };

  const approveTrooper = async (trooperId: number) => {
    setActionLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/supervisor/approve-trooper/${trooperId}`, {
        method: 'POST',
        credentials: 'include',
      });

      if (response.ok) {
        fetchPendingTroopers();
        setSelectedTrooper(null);
        setActionType(null);
      } else {
        setError('Failed to approve trooper');
      }
    } catch (error) {
      setError('Failed to approve trooper');
    } finally {
      setActionLoading(false);
    }
  };

  const denyTrooper = async (trooperId: number) => {
    if (!denialReason.trim()) {
      setError('Denial reason is required');
      return;
    }

    setActionLoading(true);
    setError('');
    try {
      const response = await fetch(`/api/supervisor/deny-trooper/${trooperId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ denial_reason: denialReason }),
      });

      if (response.ok) {
        setSelectedTrooper(null);
        setDenialReason('');
        setActionType(null);
        fetchPendingTroopers();
      } else {
        setError('Failed to deny trooper');
      }
    } catch (error) {
      setError('Failed to deny trooper');
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div>
      {error && (
        <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm mb-4">
          {error}
        </div>
      )}

      <div className="grid gap-4">
        {troopers.map((trooper) => (
          <div key={trooper.id} className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <User className="w-5 h-5 text-blue-400" />
                  <h3 className="text-lg font-semibold">{trooper.rank} {trooper.first_name} {trooper.last_name}</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <label className="text-gray-400">Serial Number</label>
                    <p className="font-semibold">
                      {trooper.serial_number.length > 8 ? `...${trooper.serial_number.slice(-5)}` : trooper.serial_number}
                    </p>
                  </div>
                  <div>
                    <label className="text-gray-400">Callsign</label>
                    <p className="font-semibold">{trooper.callsign}</p>
                  </div>
                  <div>
                    <label className="text-gray-400">Submitted</label>
                    <p className="font-semibold">{new Date(trooper.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-4">
              <button
                onClick={() => {
                  setSelectedTrooper(trooper);
                  setActionType('approve');
                }}
                disabled={actionLoading}
                className="flex items-center gap-2 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
              >
                <Check className="w-4 h-4" />
                Approve
              </button>
              <button
                onClick={() => {
                  setSelectedTrooper(trooper);
                  setActionType('deny');
                }}
                disabled={actionLoading}
                className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
              >
                <X className="w-4 h-4" />
                Deny
              </button>
            </div>
          </div>
        ))}
      </div>

      {troopers.length === 0 && (
        <div className="bg-gray-800 rounded-xl p-8 text-center border border-gray-700">
          <p className="text-gray-400">No pending profiles to review</p>
        </div>
      )}

      {/* Action Modal */}
      {selectedTrooper && actionType && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl p-6 max-w-lg w-full border border-gray-700">
            <h3 className="text-xl font-semibold mb-4">
              {actionType === 'approve' ? 'Approve' : 'Deny'} Profile
            </h3>
            
            <div className="mb-4 p-4 bg-gray-900/50 rounded-lg">
              <p className="font-semibold">{selectedTrooper.rank} {selectedTrooper.first_name} {selectedTrooper.last_name}</p>
              <p className="text-sm text-gray-400">Serial: {selectedTrooper.serial_number.length > 8 ? `...${selectedTrooper.serial_number.slice(-5)}` : selectedTrooper.serial_number}</p>
              <p className="text-sm text-gray-400">Callsign: {selectedTrooper.callsign}</p>
            </div>

            {actionType === 'approve' ? (
              <div className="bg-green-900/20 border border-green-700 rounded-lg p-3 mb-4">
                <p className="text-sm text-green-400">
                  This trooper will be granted access to the system and can begin submitting reports.
                </p>
              </div>
            ) : (
              <>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Denial Reason (Required)
                  </label>
                  <textarea
                    value={denialReason}
                    onChange={(e) => setDenialReason(e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
                    rows={4}
                    placeholder="Explain why this profile is being denied..."
                    required
                  />
                </div>

                <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 mb-4">
                  <p className="text-sm text-red-400">
                    The trooper will be notified of the denial and can resubmit a corrected profile.
                  </p>
                </div>
              </>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => {
                  if (actionType === 'approve') {
                    approveTrooper(selectedTrooper.id);
                  } else {
                    denyTrooper(selectedTrooper.id);
                  }
                }}
                disabled={actionLoading || (actionType === 'deny' && !denialReason.trim())}
                className={`flex-1 ${actionType === 'approve' ? 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800' : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800'} disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:cursor-not-allowed`}
              >
                {actionLoading ? (actionType === 'approve' ? 'Approving...' : 'Denying...') : (actionType === 'approve' ? 'Confirm Approval' : 'Confirm Denial')}
              </button>
              <button
                onClick={() => {
                  setSelectedTrooper(null);
                  setActionType(null);
                  setDenialReason('');
                  setError('');
                }}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
