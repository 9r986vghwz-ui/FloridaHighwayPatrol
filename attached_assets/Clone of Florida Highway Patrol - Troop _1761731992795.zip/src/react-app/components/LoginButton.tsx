import { useAuth } from '@getmocha/users-service/react';
import { LogIn } from 'lucide-react';

export default function LoginButton() {
  const { redirectToLogin } = useAuth();

  return (
    <button
      onClick={redirectToLogin}
      className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-blue-500/20"
    >
      <LogIn className="w-5 h-5" />
      Sign in with Google
    </button>
  );
}
