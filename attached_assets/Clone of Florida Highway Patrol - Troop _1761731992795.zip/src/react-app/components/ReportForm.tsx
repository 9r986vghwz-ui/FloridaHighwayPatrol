import { useState, useEffect } from 'react';
import { CreateReportType } from '@/shared/types';
import { FileText, MapPin, Calendar, Hash } from 'lucide-react';

interface ReportFormProps {
  onSuccess: () => void;
  reportId?: number;
  initialData?: any;
}

export default function ReportForm({ onSuccess, reportId, initialData }: ReportFormProps) {
  const [reportType, setReportType] = useState<'citation' | 'arrest' | 'bolo' | 'collision'>('citation');
  const [formData, setFormData] = useState({
    report_number: '',
    location: '',
    incident_date: '',
    report_data: {} as any,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [generatedReportNumber, setGeneratedReportNumber] = useState('');

  useEffect(() => {
    if (initialData) {
      setReportType(initialData.report_type);
      setFormData({
        report_number: initialData.report_number || '',
        location: initialData.location || '',
        incident_date: initialData.incident_date ? initialData.incident_date.replace('Z', '').substring(0, 16) : '',
        report_data: typeof initialData.report_data === 'string' ? JSON.parse(initialData.report_data) : initialData.report_data,
      });
      setGeneratedReportNumber(initialData.report_number || '');
    }
  }, [initialData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (reportId) {
        // Update existing report
        const response = await fetch(`/api/reports/${reportId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({
            report_data: formData.report_data,
            location: formData.location || undefined,
            incident_date: formData.incident_date || undefined,
          }),
        });

        if (response.ok) {
          onSuccess();
        } else {
          const errorData = await response.json();
          setError(errorData.error || 'Failed to update report');
        }
      } else {
        // Create new report
        const reportData: CreateReportType = {
          report_type: reportType,
          report_number: formData.report_number || undefined,
          location: formData.location || undefined,
          incident_date: formData.incident_date || undefined,
          report_data: formData.report_data,
        };

        const response = await fetch('/api/reports', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(reportData),
        });

        if (response.ok) {
          const result = await response.json();
          setGeneratedReportNumber(result.report_number);
          onSuccess();
          // Reset form
          setFormData({
            report_number: '',
            location: '',
            incident_date: '',
            report_data: {},
          });
        } else {
          const errorData = await response.json();
          setError(errorData.error || 'Failed to create report');
        }
      }
    } catch (err) {
      setError('Failed to submit report');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleReportDataChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      report_data: {
        ...prev.report_data,
        [field]: value
      }
    }));
  };

  const renderReportTypeFields = () => {
    switch (reportType) {
      case 'citation':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Violation Type
              </label>
              <input
                type="text"
                value={formData.report_data.violation_type || ''}
                onChange={(e) => handleReportDataChange('violation_type', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g., Speeding, Running red light"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Fine Amount
              </label>
              <input
                type="number"
                value={formData.report_data.fine_amount || ''}
                onChange={(e) => handleReportDataChange('fine_amount', parseFloat(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0.00"
                step="0.01"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Driver License #
              </label>
              <input
                type="text"
                value={formData.report_data.license_number || ''}
                onChange={(e) => handleReportDataChange('license_number', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="License number"
              />
            </div>
          </div>
        );
      case 'arrest':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Charges
              </label>
              <textarea
                onChange={(e) => handleReportDataChange('charges', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="List of charges"
                rows={3}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Suspect Name
              </label>
              <input
                type="text"
                onChange={(e) => handleReportDataChange('suspect_name', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Full name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Booking Number
              </label>
              <input
                type="text"
                onChange={(e) => handleReportDataChange('booking_number', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Booking number"
              />
            </div>
          </div>
        );
      case 'bolo':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Subject Description
              </label>
              <textarea
                onChange={(e) => handleReportDataChange('subject_description', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Physical description, clothing, etc."
                rows={3}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Vehicle Description
              </label>
              <input
                type="text"
                onChange={(e) => handleReportDataChange('vehicle_description', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Make, model, color, license plate"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Reason for BOLO
              </label>
              <textarea
                onChange={(e) => handleReportDataChange('reason', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Reason for be on lookout"
                rows={2}
                required
              />
            </div>
          </div>
        );
      case 'collision':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Number of Vehicles
              </label>
              <input
                type="number"
                onChange={(e) => handleReportDataChange('vehicle_count', parseInt(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Number of vehicles involved"
                min="1"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Injuries
              </label>
              <select
                onChange={(e) => handleReportDataChange('injuries', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select injury status</option>
                <option value="none">No injuries</option>
                <option value="minor">Minor injuries</option>
                <option value="serious">Serious injuries</option>
                <option value="fatal">Fatalities</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Description
              </label>
              <textarea
                onChange={(e) => handleReportDataChange('description', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Brief description of the collision"
                rows={3}
                required
              />
            </div>
          </div>
        );
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 max-w-2xl">
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-blue-400" />
        <h3 className="text-xl font-semibold">New Report</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Report Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Report Type
          </label>
          <div className="grid grid-cols-2 gap-3">
            {(['citation', 'arrest', 'bolo', 'collision'] as const).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setReportType(type)}
                className={`p-3 rounded-lg border transition-colors capitalize ${
                  reportType === type
                    ? 'bg-blue-600 border-blue-500 text-white'
                    : 'bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Basic Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Hash className="w-4 h-4 inline mr-1" />
              Report Number
            </label>
            <input
              type="text"
              name="report_number"
              value={formData.report_number || generatedReportNumber}
              className="w-full bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-gray-400 cursor-not-allowed"
              placeholder="Auto-generated (FHP-0001, FHP-0002, etc.)"
              disabled
              readOnly
            />
            {!reportId && (
              <p className="text-xs text-gray-500 mt-1">Report number will be auto-generated starting with FHP-0001</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Incident Date/Time
            </label>
            <input
              type="datetime-local"
              name="incident_date"
              value={formData.incident_date}
              onChange={handleChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            <MapPin className="w-4 h-4 inline mr-1" />
            Location
          </label>
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Street address or intersection"
          />
        </div>

        {/* Report Type Specific Fields */}
        <div>
          <h4 className="text-lg font-medium text-gray-300 mb-4 capitalize">
            {reportType} Details
          </h4>
          {renderReportTypeFields()}
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
        >
          {loading ? (reportId ? 'Updating Report...' : 'Creating Report...') : (reportId ? 'Update Report' : 'Create Report')}
        </button>
      </form>
    </div>
  );
}
