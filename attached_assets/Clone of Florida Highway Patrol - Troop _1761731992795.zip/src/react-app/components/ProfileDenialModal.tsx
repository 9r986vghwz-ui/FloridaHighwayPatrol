import { X, AlertTriangle } from 'lucide-react';

interface ProfileDenialModalProps {
  trooper: {
    id: number;
    serial_number: string;
    callsign: string;
    first_name: string;
    last_name: string;
    rank: string;
  };
  denialReason: string;
  onResubmit: () => void;
}

export default function ProfileDenialModal({ trooper, denialReason, onResubmit }: ProfileDenialModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-red-900/30 rounded-lg flex items-center justify-center">
              <X className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Profile Denied</h2>
              <p className="text-sm text-gray-400">Your profile submission was denied</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Denial Message */}
          <div className="bg-red-900/20 border border-red-700 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <p className="font-semibold text-red-100">Denial Reason:</p>
            </div>
            <p className="text-red-200">{denialReason}</p>
          </div>

          {/* Profile Details */}
          <div className="bg-gray-900/50 rounded-lg p-4">
            <h3 className="font-semibold mb-3 text-gray-200">Your Profile Details:</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Serial #:</span>
                <span className="text-white">
                  {trooper.serial_number.length > 8 ? `...${trooper.serial_number.slice(-5)}` : trooper.serial_number}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Callsign:</span>
                <span className="text-white">{trooper.callsign}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Name:</span>
                <span className="text-white">{trooper.first_name} {trooper.last_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Rank:</span>
                <span className="text-white">{trooper.rank}</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <button
            onClick={onResubmit}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200"
          >
            Create New Profile
          </button>

          <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-3">
            <p className="text-sm text-yellow-400">
              Please review the denial reason above and correct any issues before creating a new profile.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
