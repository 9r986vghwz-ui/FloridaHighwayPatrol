import { useState } from 'react';
import { CreateTrooperType } from '@/shared/types';
import { User, Badge, Hash, Phone } from 'lucide-react';

interface TrooperRegistrationProps {
  onSuccess: () => void;
}

export default function TrooperRegistration({ onSuccess }: TrooperRegistrationProps) {
  const [formData, setFormData] = useState<CreateTrooperType>({
    serial_number: '',
    callsign: '',
    first_name: '',
    last_name: '',
    rank: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Validate serial number length
    if (formData.serial_number.length <= 8) {
      setError('Serial number must be more than 8 digits');
      setLoading(false);
      return;
    }

    try {
      // First check if user is authenticated
      const authResponse = await fetch('/api/users/me', {
        credentials: 'include'
      });
      
      if (!authResponse.ok) {
        setError('You must be logged in to create a profile. Please refresh and try logging in again.');
        setLoading(false);
        return;
      }

      const response = await fetch('/api/troopers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        console.log('Profile created successfully');
        onSuccess();
      } else if (response.status === 409) {
        // Profile already exists, redirect to dashboard
        const errorData = await response.json().catch(() => ({ error: 'Profile already exists' }));
        console.log('Profile already exists, redirecting to dashboard');
        if (errorData.redirect_to_dashboard) {
          onSuccess();
        } else {
          setError('Profile already exists. Please refresh the page.');
        }
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error occurred' }));
        console.error('Profile creation failed:', JSON.stringify(errorData, null, 2));
        setError(errorData.error || 'Failed to create trooper profile. Please try again.');
      }
    } catch (err) {
      console.error('Registration error:', err);
      setError('Network error. Please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
      <div className="text-center mb-6">
        <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Badge className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Create Trooper Profile</h2>
        <p className="text-gray-400">
          Complete your registration to access the dashboard
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            <Hash className="w-4 h-4 inline mr-1" />
            Serial Number
          </label>
          <input
            type="text"
            name="serial_number"
            value={formData.serial_number}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter your serial number"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            <Phone className="w-4 h-4 inline mr-1" />
            Callsign
          </label>
          <input
            type="text"
            name="callsign"
            value={formData.callsign}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter your callsign"
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              First Name
            </label>
            <input
              type="text"
              name="first_name"
              value={formData.first_name}
              onChange={handleChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="First name"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Last Name
            </label>
            <input
              type="text"
              name="last_name"
              value={formData.last_name}
              onChange={handleChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Last name"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            <User className="w-4 h-4 inline mr-1" />
            Rank
          </label>
          <select
            name="rank"
            value={formData.rank}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          >
            <option value="">Select your rank</option>
            <option value="Trooper">Trooper</option>
            <option value="Corporal">Corporal</option>
            <option value="Sergeant">Sergeant</option>
            <option value="Lieutenant">Lieutenant</option>
            <option value="Captain">Captain</option>
            <option value="Major">Major</option>
            <option value="Colonel">Colonel</option>
            <option value="Chief">Chief</option>
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
        >
          {loading ? 'Creating Profile...' : 'Create Profile'}
        </button>

        <p className="text-sm text-gray-400 text-center">
          Your profile will require supervisor approval before access is granted
        </p>
      </form>
    </div>
  );
}
