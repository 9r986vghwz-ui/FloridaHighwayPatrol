import { useState, useEffect } from 'react';
import { BarChart3, FileText, Users, AlertTriangle, Car } from 'lucide-react';

interface ReportStats {
  total: number;
  by_type: Array<{
    report_type: string;
    count: number;
  }>;
}

export default function ReportStats() {
  const [stats, setStats] = useState<ReportStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/reports/stats', {
        credentials: 'include'
      });
      if (response.ok) {
        const statsData = await response.json();
        setStats(statsData);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatsByType = (type: string) => {
    return stats?.by_type.find(stat => stat.report_type === type)?.count || 0;
  };

  const getIconForType = (type: string) => {
    switch (type) {
      case 'citation':
        return <FileText className="w-6 h-6" />;
      case 'arrest':
        return <Users className="w-6 h-6" />;
      case 'bolo':
        return <AlertTriangle className="w-6 h-6" />;
      case 'collision':
        return <Car className="w-6 h-6" />;
      default:
        return <FileText className="w-6 h-6" />;
    }
  };

  const getColorForType = (type: string) => {
    switch (type) {
      case 'citation':
        return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
      case 'arrest':
        return 'text-red-400 bg-red-400/10 border-red-400/20';
      case 'bolo':
        return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
      case 'collision':
        return 'text-purple-400 bg-purple-400/10 border-purple-400/20';
      default:
        return 'text-gray-400 bg-gray-400/10 border-gray-400/20';
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-700 rounded mb-4 w-32"></div>
          <div className="space-y-3">
            <div className="h-16 bg-gray-700 rounded"></div>
            <div className="h-16 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
      <div className="flex items-center gap-3 mb-6">
        <BarChart3 className="w-6 h-6 text-blue-400" />
        <h3 className="text-xl font-semibold">Report Statistics</h3>
      </div>

      {/* Total Reports */}
      <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border border-blue-400/30 rounded-lg p-4 mb-6">
        <div className="text-center">
          <div className="text-3xl font-bold text-blue-400 mb-1">
            {stats?.total || 0}
          </div>
          <div className="text-gray-300">Total Reports Submitted</div>
        </div>
      </div>

      {/* Reports by Type */}
      <div className="grid grid-cols-2 gap-4">
        {['citation', 'arrest', 'bolo', 'collision'].map((type) => {
          const count = getStatsByType(type);
          const colorClass = getColorForType(type);
          
          return (
            <div
              key={type}
              className={`border rounded-lg p-4 ${colorClass}`}
            >
              <div className="flex items-center gap-3">
                {getIconForType(type)}
                <div>
                  <div className="text-lg font-semibold">{count}</div>
                  <div className="text-sm opacity-75 capitalize">{type}s</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {stats?.total === 0 && (
        <div className="text-center py-4 text-gray-400">
          <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
          <p>No reports submitted yet</p>
        </div>
      )}
    </div>
  );
}
