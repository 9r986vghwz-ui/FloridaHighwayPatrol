import { useState } from 'react';
import { Key, Plus, Copy, Clock } from 'lucide-react';

interface KeyCreatorProps {
  trooperSerialNumber: string;
  onClose: () => void;
}

export default function KeyCreator({ trooperSerialNumber, onClose }: KeyCreatorProps) {
  const [generatedKey, setGeneratedKey] = useState<{code: string, expiresAt: string} | null>(null);
  const [generatingKey, setGeneratingKey] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const generateSupervisorKey = async () => {
    setGeneratingKey(true);
    setError('');
    setGeneratedKey(null);

    try {
      const response = await fetch('/api/trooper/create-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const data = await response.json();
        setGeneratedKey({
          code: data.key_code,
          expiresAt: data.expires_at
        });
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to generate key');
      }
    } catch (err) {
      setError('Failed to generate key');
    } finally {
      setGeneratingKey(false);
    }
  };

  const copyToClipboard = () => {
    if (generatedKey) {
      navigator.clipboard.writeText(generatedKey.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diff = expiry.getTime() - now.getTime();
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    
    if (diff <= 0) {
      return 'Expired';
    }
    
    return `${minutes}m ${seconds}s`;
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 w-full max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Plus className="w-6 h-6 text-purple-400" />
            <h3 className="text-xl font-semibold">Create Supervisor Access Key</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>

        {error && (
          <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm mb-4">
            {error}
          </div>
        )}

        {!generatedKey ? (
          <div className="space-y-4">
            <p className="text-gray-300">
              Generate a temporary supervisor access key that will remain active for 15 minutes.
              This key will be marked as created by your serial number: <span className="font-mono text-blue-400">{trooperSerialNumber}</span>
            </p>
            
            <button
              onClick={generateSupervisorKey}
              disabled={generatingKey}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {generatingKey ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Generating...
                </>
              ) : (
                <>
                  <Key className="w-4 h-4" />
                  Generate New Key
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-gray-900 rounded-lg p-4 border border-purple-500">
              <label className="text-sm text-gray-400 block mb-2">Generated Key</label>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-2xl font-mono text-purple-400 tracking-wider">
                  {generatedKey.code}
                </code>
                <button
                  onClick={copyToClipboard}
                  className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-lg transition-colors"
                  title="Copy to clipboard"
                >
                  <Copy className="w-5 h-5" />
                </button>
              </div>
              {copied && (
                <p className="text-sm text-green-400 mt-2">✓ Copied to clipboard!</p>
              )}
            </div>

            <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4">
              <div className="flex items-center gap-2 text-yellow-400 mb-2">
                <Clock className="w-4 h-4" />
                <span className="font-semibold">Time Remaining</span>
              </div>
              <p className="text-2xl font-mono text-yellow-300">
                {getTimeRemaining(generatedKey.expiresAt)}
              </p>
              <p className="text-sm text-gray-400 mt-2">
                Expires at {new Date(generatedKey.expiresAt).toLocaleTimeString()}
              </p>
              <p className="text-sm text-gray-300 mt-2">
                Created by: <span className="font-mono text-blue-400">{trooperSerialNumber}</span>
              </p>
            </div>

            <button
              onClick={() => setGeneratedKey(null)}
              className="w-full bg-gray-700 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
            >
              Generate Another Key
            </button>
          </div>
        )}

        <div className="mt-6 p-4 bg-blue-900/20 border border-blue-700 rounded-lg">
          <h4 className="font-semibold text-blue-400 mb-2">Key Information</h4>
          <ul className="text-sm text-gray-300 space-y-1">
            <li>• Each key is randomly generated and unique</li>
            <li>• Keys automatically expire after 15 minutes</li>
            <li>• Share the key with supervisors who need temporary access</li>
            <li>• Generate a new key whenever needed</li>
            <li>• All keys are tracked with creator information</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
