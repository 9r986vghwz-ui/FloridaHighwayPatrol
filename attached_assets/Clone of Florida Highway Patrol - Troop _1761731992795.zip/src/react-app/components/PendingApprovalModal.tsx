import { useState } from 'react';
import { User, Key, Shield } from 'lucide-react';

interface PendingApprovalModalProps {
  trooper: {
    serial_number: string;
    callsign: string;
    first_name: string;
    last_name: string;
    rank: string;
  };
  onAdminApproval: () => void;
}

export default function PendingApprovalModal({ trooper, onAdminApproval }: PendingApprovalModalProps) {
  const [showAdminSection, setShowAdminSection] = useState(false);
  const [adminKey, setAdminKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAdminKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/supervisor/verify-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ key_code: adminKey }),
      });

      if (response.ok) {
        // If key is valid, approve the current user's trooper profile
        const trooperResponse = await fetch('/api/troopers/me', {
          credentials: 'include'
        });
        if (trooperResponse.ok) {
          const trooperData = await trooperResponse.json();
          
          const approveResponse = await fetch(`/api/supervisor/approve-trooper/${trooperData.id}`, {
            method: 'POST',
            credentials: 'include'
          });
          
          if (approveResponse.ok) {
            onAdminApproval();
          } else {
            setError('Failed to approve profile');
          }
        } else {
          setError('Failed to get profile information');
        }
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Invalid admin key');
      }
    } catch (err) {
      setError('Failed to verify admin key');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-yellow-900/30 rounded-lg flex items-center justify-center">
              <User className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Pending Approval</h2>
              <p className="text-sm text-gray-400">Profile submitted successfully</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Approval Message */}
          <div className="bg-yellow-900/20 border border-yellow-700 rounded-lg p-4">
            <p className="text-yellow-100 text-center leading-relaxed">
              Your profile is pending approval by a supervisor. Feel free to contact a LT+ for approval.
            </p>
          </div>

          {/* Profile Details */}
          <div className="bg-gray-900/50 rounded-lg p-4">
            <h3 className="font-semibold mb-3 text-gray-200">Profile Details:</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Serial #:</span>
                <span className="text-white">{trooper.serial_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Callsign:</span>
                <span className="text-white">{trooper.callsign}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Name:</span>
                <span className="text-white">{trooper.first_name} {trooper.last_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Rank:</span>
                <span className="text-white">{trooper.rank}</span>
              </div>
            </div>
          </div>

          {/* Admin Section Toggle */}
          <div className="border-t border-gray-700 pt-6">
            {!showAdminSection ? (
              <button
                onClick={() => setShowAdminSection(true)}
                className="w-full bg-purple-900/30 hover:bg-purple-900/50 border border-purple-700 rounded-lg p-4 transition-colors group"
              >
                <div className="flex items-center justify-center gap-3">
                  <Shield className="w-5 h-5 text-purple-400" />
                  <span className="text-purple-300 font-medium">Are you an admin? Enter your key for instant access</span>
                </div>
              </button>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <Key className="w-5 h-5 text-purple-400" />
                  <h3 className="font-semibold text-purple-300">Admin Access</h3>
                </div>
                
                <form onSubmit={handleAdminKeySubmit} className="space-y-4">
                  {error && (
                    <div className="bg-red-900/20 border border-red-700 rounded-lg p-3 text-red-400 text-sm">
                      {error}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Admin Key
                    </label>
                    <input
                      type="password"
                      value={adminKey}
                      onChange={(e) => setAdminKey(e.target.value)}
                      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Enter admin key"
                      required
                    />
                  </div>

                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        setShowAdminSection(false);
                        setAdminKey('');
                        setError('');
                      }}
                      className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Verifying...' : 'Approve'}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
