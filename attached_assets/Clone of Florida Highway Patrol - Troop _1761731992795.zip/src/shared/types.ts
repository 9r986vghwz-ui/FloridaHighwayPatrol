import z from "zod";

export const TrooperSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  serial_number: z.string(),
  callsign: z.string(),
  first_name: z.string(),
  last_name: z.string(),
  rank: z.string(),
  phone: z.string().nullable(),
  email: z.string().nullable(),
  badge_number: z.string().nullable(),
  is_approved: z.boolean(),
  approved_by_user_id: z.string().nullable(),
  approved_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTrooperSchema = z.object({
  serial_number: z.string().min(9, "Serial number must be more than 8 digits"),
  callsign: z.string().min(1, "Callsign is required"),
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  rank: z.string().min(1, "Rank is required"),
  phone: z.string().optional(),
  email: z.string().optional(),
  badge_number: z.string().optional(),
});

export const UpdateTrooperSchema = z.object({
  callsign: z.string().min(1, "Callsign is required"),
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  rank: z.string().min(1, "Rank is required"),
});

export const ReportSchema = z.object({
  id: z.number(),
  trooper_id: z.number(),
  report_type: z.enum(['citation', 'arrest', 'bolo', 'collision']),
  report_data: z.string(),
  report_number: z.string().nullable(),
  location: z.string().nullable(),
  incident_date: z.string().nullable(),
  report_status: z.string().nullable(),
  denial_notes: z.string().nullable(),
  denied_at: z.string().nullable(),
  denied_by_user_id: z.string().nullable(),
  needs_revision: z.boolean().nullable(),
  revised_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateReportSchema = z.object({
  report_type: z.enum(['citation', 'arrest', 'bolo', 'collision']),
  report_data: z.object({}).passthrough(),
  report_number: z.string().optional(),
  location: z.string().optional(),
  incident_date: z.string().optional(),
});

export const SupervisorKeySchema = z.object({
  id: z.number(),
  key_code: z.string(),
  is_active: z.boolean(),
  created_by_user_id: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const StrikeSchema = z.object({
  id: z.number(),
  trooper_id: z.number(),
  report_id: z.number().nullable(),
  reason: z.string(),
  issued_by_user_id: z.string(),
  issued_at: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type TrooperType = z.infer<typeof TrooperSchema>;
export type CreateTrooperType = z.infer<typeof CreateTrooperSchema>;
export type UpdateTrooperType = z.infer<typeof UpdateTrooperSchema>;
export type ReportType = z.infer<typeof ReportSchema>;
export type CreateReportType = z.infer<typeof CreateReportSchema>;
export type SupervisorKeyType = z.infer<typeof SupervisorKeySchema>;
export type StrikeType = z.infer<typeof StrikeSchema>;
