import { Hono } from "hono";
import { cors } from "hono/cors";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
  getCurrentUser,
} from "@getmocha/users-service/backend";
import {
  CreateTrooperSchema,
  UpdateTrooperSchema,
  CreateReportSchema,
  TrooperSchema,
  ReportSchema,
} from "@/shared/types";
import "./env.d.ts";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  credentials: true,
}));

// Auth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "lax",
    secure: false, // Allow for local development
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  
  if (!sessionToken) {
    return c.json({ error: "No session token" }, 401);
  }
  
  try {
    const user = await getCurrentUser(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
    
    if (!user) {
      return c.json({ error: "Invalid session token" }, 401);
    }
    
    return c.json(user);
  } catch (error) {
    console.error('Error fetching user:', error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'lax',
    secure: false,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Custom auth middleware that works properly
const requireAuth = async (c: any, next: any) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  
  if (!sessionToken) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  try {
    const user = await getCurrentUser(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
    
    if (!user) {
      return c.json({ error: "Invalid session" }, 401);
    }
    
    c.set("user", user);
    await next();
  } catch (error) {
    console.error('Auth error:', error);
    return c.json({ error: "Authentication failed" }, 401);
  }
};

// Trooper routes
app.post("/api/troopers", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  try {
    console.log(`Creating trooper profile for user_id: ${user.id}`);
    const body = await c.req.json();
    const validatedData = CreateTrooperSchema.parse(body);
    console.log('Validated trooper data:', validatedData);

    // Validate serial number length
    if (validatedData.serial_number.length <= 8) {
      return c.json({ error: "Serial number must be more than 8 digits" }, 400);
    }
  
    // Check if user already has a trooper profile
    const existingTrooper = await c.env.DB.prepare(
      "SELECT * FROM troopers WHERE user_id = ?"
    ).bind(user.id).first();
    
    if (existingTrooper) {
      console.log(`Trooper profile already exists for user_id: ${user.id}`, existingTrooper);
      // Convert SQLite boolean values to actual booleans
      const normalizedTrooper = {
        ...existingTrooper,
        is_approved: Boolean(existingTrooper.is_approved)
      };
      // Instead of returning error, return the existing profile
      return c.json({ 
        error: "Trooper profile already exists", 
        trooper: TrooperSchema.parse(normalizedTrooper),
        redirect_to_dashboard: true 
      }, 409);
    }
    
    // Check if serial number is already taken
    const existingSerial = await c.env.DB.prepare(
      "SELECT * FROM troopers WHERE serial_number = ?"
    ).bind(validatedData.serial_number).first();
    
    if (existingSerial) {
      console.log(`Serial number already exists: ${validatedData.serial_number}`);
      return c.json({ error: "Serial number already exists" }, 400);
    }
    
    const result = await c.env.DB.prepare(`
        INSERT INTO troopers (user_id, serial_number, callsign, first_name, last_name, rank, phone, email, badge_number, profile_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
      `).bind(
        user.id,
        validatedData.serial_number,
        validatedData.callsign,
        validatedData.first_name,
        validatedData.last_name,
        validatedData.rank,
        validatedData.phone || null,
        validatedData.email || null,
        validatedData.badge_number || null
      ).run();
      
      console.log(`Created trooper profile with id: ${result.meta.last_row_id}`);
      return c.json({ id: result.meta.last_row_id, success: true }, 201);
  } catch (error) {
    console.error('Error creating trooper profile:', error);
    if (error instanceof Error) {
      return c.json({ error: error.message }, 400);
    }
    return c.json({ error: 'Failed to create trooper profile' }, 500);
  }
});

app.delete("/api/troopers/me", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  try {
    // Delete trooper profile to allow resubmission
    await c.env.DB.prepare(
      "DELETE FROM troopers WHERE user_id = ?"
    ).bind(user.id).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting trooper profile:', error);
    return c.json({ error: 'Failed to delete trooper profile' }, 500);
  }
});

app.get("/api/troopers/me", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  try {
    console.log(`Fetching trooper profile for user_id: ${user.id}`);
    const trooper = await c.env.DB.prepare(
      "SELECT * FROM troopers WHERE user_id = ?"
    ).bind(user.id).first();
    
    if (!trooper) {
      console.log(`No trooper profile found for user_id: ${user.id}`);
      return c.json({ error: "Trooper profile not found" }, 404);
    }
    
    console.log(`Found trooper profile:`, trooper);
    
    // Convert SQLite boolean values to actual booleans
    const normalizedTrooper = {
      ...trooper,
      is_approved: Boolean(trooper.is_approved)
    };
    
    return c.json(TrooperSchema.parse(normalizedTrooper));
  } catch (error) {
    console.error('Error fetching trooper profile:', error);
    return c.json({ error: 'Failed to fetch trooper profile' }, 500);
  }
});

app.put("/api/troopers/me", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  try {
    const body = await c.req.json();
    const validatedData = UpdateTrooperSchema.parse(body);
    
    // Check if user has a trooper profile
    const trooper = await c.env.DB.prepare(
      "SELECT * FROM troopers WHERE user_id = ?"
    ).bind(user.id).first();
    
    if (!trooper) {
      return c.json({ error: "Trooper profile not found" }, 404);
    }
    
    await c.env.DB.prepare(`
      UPDATE troopers 
      SET callsign = ?, first_name = ?, last_name = ?, rank = ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).bind(
      validatedData.callsign,
      validatedData.first_name,
      validatedData.last_name,
      validatedData.rank,
      user.id
    ).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error updating trooper profile:', error);
    if (error instanceof Error) {
      return c.json({ error: error.message }, 400);
    }
    return c.json({ error: 'Failed to update trooper profile' }, 500);
  }
});

// Reports routes
app.post("/api/reports", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const body = await c.req.json();
  
  const validatedData = CreateReportSchema.parse(body);
  
  // Get trooper profile
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ? AND is_approved = 1"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Approved trooper profile required" }, 403);
  }
  
  // Generate report number if not provided
  let reportNumber = validatedData.report_number;
  if (!reportNumber) {
    // Get the highest report number
    const lastReport = await c.env.DB.prepare(
      "SELECT report_number FROM reports WHERE report_number LIKE 'FHP-%' ORDER BY id DESC LIMIT 1"
    ).first();
    
    let nextNumber = 1;
    if (lastReport && lastReport.report_number) {
      const match = (lastReport.report_number as string).match(/FHP-(\d+)/);
      if (match) {
        nextNumber = parseInt(match[1]) + 1;
      }
    }
    
    reportNumber = `FHP-${String(nextNumber).padStart(4, '0')}`;
  }
  
  const result = await c.env.DB.prepare(`
    INSERT INTO reports (trooper_id, report_type, report_data, report_number, location, incident_date, report_status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `).bind(
    trooper.id,
    validatedData.report_type,
    JSON.stringify(validatedData.report_data),
    reportNumber,
    validatedData.location || null,
    validatedData.incident_date || null
  ).run();
  
  return c.json({ id: result.meta.last_row_id, report_number: reportNumber, success: true }, 201);
});

app.get("/api/reports", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Trooper profile not found" }, 404);
  }
  
  const reports = await c.env.DB.prepare(
    "SELECT * FROM reports WHERE trooper_id = ? ORDER BY created_at DESC"
  ).bind(trooper.id).all();
  
  const normalizedReports = reports.results.map(report => ({
    ...report,
    needs_revision: Boolean(report.needs_revision)
  }));
  
  return c.json(normalizedReports.map(report => ReportSchema.parse(report)));
});

app.put("/api/reports/:id", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const reportId = c.req.param("id");
  const body = await c.req.json();
  
  // Get trooper profile
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Trooper profile not found" }, 404);
  }
  
  // Verify the report belongs to this trooper
  const report = await c.env.DB.prepare(
    "SELECT * FROM reports WHERE id = ? AND trooper_id = ?"
  ).bind(reportId, trooper.id).first();
  
  if (!report) {
    return c.json({ error: "Report not found" }, 404);
  }
  
  // Update the report
  await c.env.DB.prepare(`
    UPDATE reports 
    SET report_data = ?, location = ?, incident_date = ?, report_status = 'pending', needs_revision = 0, revised_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(
    JSON.stringify(body.report_data),
    body.location || null,
    body.incident_date || null,
    reportId
  ).run();
  
  return c.json({ success: true });
});

app.get("/api/reports/stats", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Trooper profile not found" }, 404);
  }
  
  const stats = await c.env.DB.prepare(`
    SELECT 
      report_type,
      COUNT(*) as count
    FROM reports 
    WHERE trooper_id = ? 
    GROUP BY report_type
  `).bind(trooper.id).all();
  
  const totalReports = await c.env.DB.prepare(
    "SELECT COUNT(*) as total FROM reports WHERE trooper_id = ?"
  ).bind(trooper.id).first();
  
  return c.json({
    total: totalReports?.total || 0,
    by_type: stats.results
  });
});

// Supervisor routes
app.post("/api/supervisor/verify-key", requireAuth, async (c) => {
  const body = await c.req.json();
  
  if (!body.key_code) {
    return c.json({ error: "Key code is required" }, 400);
  }
  
  const key = await c.env.DB.prepare(
    "SELECT * FROM supervisor_keys WHERE key_code = ? AND is_active = 1"
  ).bind(body.key_code).first();
  
  if (!key) {
    return c.json({ error: "Invalid or inactive key" }, 401);
  }
  
  // Check if key has expired (if expires_at is set)
  if (key.expires_at) {
    const expiresAt = new Date(key.expires_at as string);
    if (expiresAt < new Date()) {
      // Deactivate expired key
      await c.env.DB.prepare(
        "UPDATE supervisor_keys SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(key.id).run();
      
      return c.json({ error: "Key has expired" }, 401);
    }
  }
  
  return c.json({ valid: true });
});

app.get("/api/supervisor/pending-troopers", requireAuth, async (c) => {
  const troopers = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE is_approved = 0 AND (profile_status = 'pending' OR profile_status IS NULL) ORDER BY created_at DESC"
  ).all();
  
  // Convert SQLite boolean values to actual booleans for all troopers
  const normalizedTroopers = troopers.results.map(trooper => ({
    ...trooper,
    is_approved: Boolean(trooper.is_approved)
  }));
  
  return c.json(normalizedTroopers.map(trooper => TrooperSchema.parse(trooper)));
});

app.post("/api/supervisor/approve-trooper/:id", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const trooperId = c.req.param("id");
  
  await c.env.DB.prepare(`
    UPDATE troopers 
    SET is_approved = 1, profile_status = 'approved', approved_by_user_id = ?, approved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(user.id, trooperId).run();
  
  return c.json({ success: true });
});

app.post("/api/supervisor/deny-trooper/:id", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  const trooperId = c.req.param("id");
  const body = await c.req.json();
  
  if (!body.denial_reason) {
    return c.json({ error: "Denial reason is required" }, 400);
  }
  
  await c.env.DB.prepare(`
    UPDATE troopers 
    SET profile_status = 'denied', denial_reason = ?, denied_by_user_id = ?, denied_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(body.denial_reason, user.id, trooperId).run();
  
  return c.json({ success: true });
});

// Route for troopers to create their own supervisor keys
app.post("/api/trooper/create-key", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  // Get trooper profile to get serial number
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Trooper profile not found" }, 404);
  }
  
  // Generate random 12-character key
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let keyCode = '';
  for (let i = 0; i < 12; i++) {
    keyCode += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  
  // Set expiration to 15 minutes from now
  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + 15);
  
  const result = await c.env.DB.prepare(`
    INSERT INTO supervisor_keys (key_code, created_by_user_id, created_by_serial_number, expires_at)
    VALUES (?, ?, ?, ?)
  `).bind(keyCode, user.id, trooper.serial_number, expiresAt.toISOString()).run();
  
  return c.json({ 
    id: result.meta.last_row_id, 
    key_code: keyCode,
    expires_at: expiresAt.toISOString(),
    success: true 
  }, 201);
});

app.get("/api/supervisor/reports", requireAuth, async (c) => {
  // Get all reports for supervisor review
  const reports = await c.env.DB.prepare(`
    SELECT r.*, t.first_name, t.last_name, t.callsign, t.serial_number, t.rank
    FROM reports r
    JOIN troopers t ON r.trooper_id = t.id
    ORDER BY r.created_at DESC
  `).all();
  
  const normalizedReports = reports.results.map(report => ({
    ...report,
    needs_revision: Boolean(report.needs_revision)
  }));
  
  return c.json(normalizedReports);
});

app.get("/api/supervisor/key-history", requireAuth, async (c) => {
  // Get all supervisor keys for viewing history
  const keys = await c.env.DB.prepare(`
    SELECT * FROM supervisor_keys 
    ORDER BY created_at DESC
  `).all();
  
  const normalizedKeys = keys.results.map(key => ({
    ...key,
    is_active: Boolean(key.is_active)
  }));
  
  return c.json(normalizedKeys);
});

app.post("/api/supervisor/reports/:id/approve", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const reportId = c.req.param("id");
  
  await c.env.DB.prepare(`
    UPDATE reports 
    SET report_status = 'approved', updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(reportId).run();
  
  return c.json({ success: true });
});

app.post("/api/supervisor/reports/:id/deny", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const reportId = c.req.param("id");
  const body = await c.req.json();
  
  if (!body.denial_notes) {
    return c.json({ error: "Denial notes are required" }, 400);
  }
  
  await c.env.DB.prepare(`
    UPDATE reports 
    SET report_status = 'denied', denial_notes = ?, denied_at = CURRENT_TIMESTAMP, denied_by_user_id = ?, needs_revision = 1, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(body.denial_notes, user.id, reportId).run();
  
  return c.json({ success: true });
});

app.post("/api/supervisor/strikes", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const body = await c.req.json();
  
  if (!body.trooper_id || !body.reason) {
    return c.json({ error: "Trooper ID and reason are required" }, 400);
  }
  
  const result = await c.env.DB.prepare(`
    INSERT INTO strikes (trooper_id, report_id, reason, issued_by_user_id)
    VALUES (?, ?, ?, ?)
  `).bind(
    body.trooper_id,
    body.report_id || null,
    body.reason,
    user.id
  ).run();
  
  return c.json({ id: result.meta.last_row_id, success: true }, 201);
});

app.get("/api/troopers/strikes", requireAuth, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Authentication required" }, 401);
  }
  
  const trooper = await c.env.DB.prepare(
    "SELECT * FROM troopers WHERE user_id = ?"
  ).bind(user.id).first();
  
  if (!trooper) {
    return c.json({ error: "Trooper profile not found" }, 404);
  }
  
  const strikes = await c.env.DB.prepare(
    "SELECT * FROM strikes WHERE trooper_id = ? ORDER BY issued_at DESC"
  ).bind(trooper.id).all();
  
  return c.json(strikes.results);
});

export default app;
